### Our data can be downloaded through the following link:

Google Drive: https://drive.google.com/drive/folders/1jApbId20lX8AY0tIsoX2_2BHBLPoxD4L?usp=sharing

Baidu Yun: https://pan.baidu.com/s/1xhzOCZQ50DuD_oYvy2Gi6A Password: 6lnq


---
If you have problems regarding our data, please email to: czhu@bupt.edu.cn, shengjie.Liu@bupt.edu.cn

We appreciate your interest in our work and data again.

Our dataset is made freely available to academic and non-academic entities for non-commercial purposes such as academic research, teaching, scientific publications, or personal experimentation.

For more information, please refer to our github: https://github.com/bupt-ai-cz or MIC Group: https://teacher.bupt.edu.cn/zhuchuang/en/index.htm

Welcome to continue to pay attention to our follow-up updates.
